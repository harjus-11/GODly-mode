#!/system/bin/sh
# ==============================================================================
# OmniUnlock — Dedicated Baseband Architecture, 3GPP TS 22.022 & TS 23.003 Kill-Switch
# File: disable-3gpp-baseband-only.sh (Standalone Script — No APK Required)
# ==============================================================================
service call phone 27 i32 0
setprop vendor.ril.baseband.architecture disabled
setprop persist.vendor.radio.3gpp.ts22022 0
settings put global ts22022_sim_personalization 0
setprop persist.vendor.radio.3gpp.ts23003 0
settings put global ts23003_imei_attestation 0
echo "[OK] Baseband Architecture, 3GPP TS 22.022 & TS 23.003 are OFF."
