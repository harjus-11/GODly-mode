@echo off
adb push shizuku-baseband-unlock.sh /data/local/tmp/shizuku-baseband-unlock.sh
adb push disable-3gpp-baseband-only.sh /data/local/tmp/disable-3gpp-baseband-only.sh
adb push restore-stock-baseband.sh /data/local/tmp/restore-stock-baseband.sh
adb push launch-secret-menus.sh /data/local/tmp/launch-secret-menus.sh
adb shell chmod +x /data/local/tmp/*.sh
adb shell sh /data/local/tmp/shizuku-baseband-unlock.sh
pause
