#!/usr/bin/env bash
if command -v rish >/dev/null 2>&1; then
  rish -c "sh ./shizuku-baseband-unlock.sh"
elif command -v adb >/dev/null 2>&1; then
  adb push shizuku-baseband-unlock.sh /data/local/tmp/shizuku-baseband-unlock.sh
  adb shell chmod +x /data/local/tmp/shizuku-baseband-unlock.sh
  adb shell sh /data/local/tmp/shizuku-baseband-unlock.sh
else
  sh ./shizuku-baseband-unlock.sh
fi
