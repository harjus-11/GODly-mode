==============================================================================
OMNIUNLOCK — STANDALONE SHIZUKU & 3GPP BASEBAND SCRIPTS (NO APK)
==============================================================================
1. shizuku-baseband-unlock.sh       — Master Shizuku UID 2000 & 3GPP override script
2. disable-3gpp-baseband-only.sh    — Turns OFF Baseband Arch, TS 22.022 & TS 23.003
3. restore-stock-baseband.sh        — Restores stock Baseband & 3GPP settings
4. launch-secret-menus.sh           — Launches hidden RadioInfo / BandLock menus
5. run-from-mac-linux-termux.sh     — Runner for Termux (rish), macOS & Linux
6. run-from-windows-adb.bat         — Runner for Windows ADB
