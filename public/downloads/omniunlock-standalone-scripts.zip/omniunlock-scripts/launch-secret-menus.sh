#!/system/bin/sh
# ==============================================================================
# OmniUnlock — Secret Engineering & Radio Menu Launcher Script
# File: launch-secret-menus.sh (Standalone Script — No APK Required)
# ==============================================================================
TARGET="${1:-radioinfo}"
case "$TARGET" in
  radioinfo|4636)
    am start -n com.android.settings/.TestingSettings 2>/dev/null || \
    am start -n com.android.phone/.settings.RadioInfo 2>/dev/null || \
    am broadcast -a android.provider.Telephony.SECRET_CODE -d android_secret_code://4636
    ;;
  bandlock|2263)
    am broadcast -a android.provider.Telephony.SECRET_CODE -d android_secret_code://2263
    ;;
  servicemode|0011)
    am broadcast -a android.provider.Telephony.SECRET_CODE -d android_secret_code://0011
    ;;
  mtk|3646633)
    am start -n com.mediatek.engineermode/.EngineerMode 2>/dev/null || \
    am broadcast -a android.provider.Telephony.SECRET_CODE -d android_secret_code://3646633
    ;;
  qcom|diag)
    am broadcast -a android.provider.Telephony.SECRET_CODE -d android_secret_code://717717
    ;;
esac
