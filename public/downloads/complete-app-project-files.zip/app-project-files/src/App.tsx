import React, { useState } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { BasebandFirmwareLab } from './components/BasebandFirmwareLab.tsx';
import { ImeiLookupView } from './components/ImeiLookupView.tsx';
import { ImeiMaskingView } from './components/ImeiMaskingView.tsx';
import { UnlockDatabaseView } from './components/UnlockDatabaseView.tsx';
import { SecretMenusView } from './components/SecretMenusView.tsx';
import { ShizukuNetworkManager } from './components/ShizukuNetworkManager.tsx';
import { ImeiChecker } from './components/ImeiChecker.tsx';
import { UnlockWizard } from './components/UnlockWizard.tsx';
import { LockStatusGuide } from './components/LockStatusGuide.tsx';
import { NckDecoder } from './components/NckDecoder.tsx';
import { CarrierDirectory } from './components/CarrierDirectory.tsx';
import { AiAdvisor } from './components/AiAdvisor.tsx';
import { SavingsCalculator } from './components/SavingsCalculator.tsx';
import { DialerModal } from './components/DialerModal.tsx';
import { ApkCompilerBackView } from './components/ApkCompilerBackView.tsx';
import { BootBiosSandboxManager } from './components/BootBiosSandboxManager.tsx';
import { downloadOmniUnlockZipBundle } from './utils/apkBuilder.ts';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('boot-bios-sandbox');
  const [wizardBrand, setWizardBrand] = useState<string>('Apple');
  const [wizardCarrier, setWizardCarrier] = useState<string>('att');
  const [isDialerModalOpen, setIsDialerModalOpen] = useState<boolean>(false);
  const [zipDownloadedToast, setZipDownloadedToast] = useState<string | null>(null);

  // Cross-view state for the Baseband & Firmware Lab
  const [labInitialTool, setLabInitialTool] = useState<'qfil' | 'odin' | 'spflash'>('qfil');
  const [labInitialModule, setLabInitialModule] = useState<
    'oem-tools' | 'nvm-uart' | 'bootrom-auth' | 'academic-specs'
  >('oem-tools');
  const [labInitialImei, setLabInitialImei] = useState<string>('352011110482917');

  const handleNavigateToWizard = (brand: string, carrier: string) => {
    setWizardBrand(brand);
    setWizardCarrier(carrier);
    setActiveTab('wizard');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateToCodesDbFromImei = (brand: string, _model: string) => {
    setWizardBrand(brand);
    setActiveTab('codes-db');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateToBasebandLab = (
    module: 'oem-tools' | 'nvm-uart' | 'bootrom-auth' | 'academic-specs' = 'oem-tools',
    tool: 'qfil' | 'odin' | 'spflash' = 'qfil',
    imei?: string
  ) => {
    setLabInitialModule(module);
    setLabInitialTool(tool);
    if (imei) setLabInitialImei(imei);
    setActiveTab('baseband-lab');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#060911] text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenDialerModal={() => setIsDialerModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'boot-bios-sandbox' && <BootBiosSandboxManager />}

        {activeTab === 'baseband-lab' && (
          <BasebandFirmwareLab
            key={`${labInitialModule}-${labInitialTool}-${labInitialImei}`}
            initialModule={labInitialModule}
            initialTool={labInitialTool}
            initialImei={labInitialImei}
          />
        )}

        {activeTab === 'imei-lookup' && (
          <ImeiLookupView
            onUnlockDevice={handleNavigateToCodesDbFromImei}
            onOpenDialerModal={() => setIsDialerModalOpen(true)}
            onNavigateToMasker={() => {
              setActiveTab('imei-masking');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenBasebandLab={(tool, imei) => handleNavigateToBasebandLab('oem-tools', tool, imei)}
          />
        )}

        {activeTab === 'imei-masking' && (
          <ImeiMaskingView
            onOpenBasebandNvm={(imei) => handleNavigateToBasebandLab('nvm-uart', 'qfil', imei)}
          />
        )}

        {activeTab === 'codes-db' && (
          <UnlockDatabaseView
            onSelectModel={(brand) => handleNavigateToWizard(brand, 'att')}
          />
        )}

        {activeTab === 'secret-menus' && (
          <SecretMenusView
            onNavigateToShizukuSetup={() => {
              setActiveTab('shizuku');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeTab === 'shizuku' && (
          <ShizukuNetworkManager
            onNavigateToSecretMenus={() => {
              setActiveTab('secret-menus');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onNavigateToBasebandCompare={() => handleNavigateToBasebandLab('bootrom-auth', 'qfil')}
          />
        )}

        {activeTab === 'imei' && (
          <ImeiChecker
            onSelectCarrier={(carrierId) => handleNavigateToWizard('Apple', carrierId)}
            onNavigateToWizard={handleNavigateToWizard}
          />
        )}

        {activeTab === 'wizard' && (
          <UnlockWizard
            initialBrand={wizardBrand}
            initialCarrier={wizardCarrier}
            onNavigateToNck={() => setActiveTab('nck')}
          />
        )}

        {activeTab === 'check-status' && (
          <LockStatusGuide
            onNavigateToImei={() => {
              setActiveTab('imei-lookup');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onNavigateToCodes={() => {
              setActiveTab('codes-db');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeTab === 'nck' && (
          <NckDecoder
            onNavigateToWizard={() => {
              setActiveTab('wizard');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onNavigateToCodes={() => {
              setActiveTab('codes-db');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeTab === 'carriers' && <CarrierDirectory />}

        {activeTab === 'advisor' && <AiAdvisor />}

        {activeTab === 'savings' && <SavingsCalculator />}

        {activeTab === 'apk-compiler' && <ApkCompilerBackView />}
      </main>

      {/* Dialer Helper Modal */}
      <DialerModal
        isOpen={isDialerModalOpen}
        onClose={() => setIsDialerModalOpen(false)}
      />

      {/* Footer (Back of the App) */}
      <footer className="mt-auto border-t border-slate-900 bg-[#060911]/90 py-8 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-3">
          {zipDownloadedToast && (
            <div className="p-3 rounded-xl bg-emerald-950/90 border border-emerald-500/40 text-emerald-200 flex items-center justify-between">
              <span className="font-mono">{zipDownloadedToast}</span>
              <button
                type="button"
                onClick={() => setZipDownloadedToast(null)}
                className="text-slate-400 hover:text-white px-2 cursor-pointer"
              >
                ✕
              </button>
            </div>
          )}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-300">OmniUnlock Carrier &amp; Baseband Suite</span>
              <span aria-hidden="true">·</span>
              <span>3GPP TS 22.022 / TS 23.003 &amp; FCC/CTIA Compliant</span>
            </div>
            <div className="flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={() => handleNavigateToBasebandLab('academic-specs', 'qfil')}
                className="text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
              >
                3GPP &amp; IEEE Citations
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('carriers')}
                className="text-slate-400 hover:text-slate-200 underline cursor-pointer"
              >
                Official Carrier Portals
              </button>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('apk-compiler');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="text-cyan-300 hover:text-cyan-200 underline font-semibold cursor-pointer"
              >
                Back-End APK &amp; .ZIP Compiler
              </button>
              <button
                type="button"
                onClick={() => {
                  const res = downloadOmniUnlockZipBundle();
                  setZipDownloadedToast(
                    `✓ Downloaded ${res.zipFilename} (${res.sizeBytes} bytes — includes Signed .APK, Standalone Mobile .HTML, Shizuku .sh script & ADB installers)`
                  );
                }}
                className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold cursor-pointer transition"
              >
                Download Complete Suite (.zip)
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
