import React, { useState, useMemo } from 'react';
import {
  Shield,
  EyeOff,
  Copy,
  Check,
  FileText,
  Sparkles,
  RefreshCw,
  AlertTriangle,
  Lock,
  Download,
  Info,
  Hash,
  Binary,
  ArrowRight,
} from 'lucide-react';
import { VERIFIED_DEVICE_PROFILES } from '../data/carriers.ts';
import { encodeImeiToNv550Hex } from '../data/basebandData.ts';

type MaskingStyle = 'support' | 'receipt' | 'strict' | 'custom' | 'token';

interface ImeiMaskingViewProps {
  onOpenBasebandNvm?: (imei: string) => void;
}

export const ImeiMaskingView: React.FC<ImeiMaskingViewProps> = ({ onOpenBasebandNvm }) => {
  // Single IMEI Masker State
  const [inputImei, setInputImei] = useState<string>('358942110294854');
  const [maskChar, setMaskChar] = useState<string>('•');
  const [selectedStyle, setSelectedStyle] = useState<MaskingStyle>('support');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Bulk Scrubber State
  const [scrubberInput, setScrubberInput] = useState<string>(
    `Subject: AT&T Device Unlock Request Confirmation
Hello Customer,

Your unlock request for Apple iPhone 15 Pro (IMEI: 358942110294854) has been processed.
IMEI 2: 358942110294862
UART NV_READ_F (0x0226): 08 3A 58 94 21 10 29 48 54

Please backup your device and insert your non-AT&T SIM card.`
  );
  const [scrubberMaskStyle, setScrubberMaskStyle] = useState<MaskingStyle>('support');

  // Synthetic Test Generator State
  const [testBrand, setTestBrand] = useState<string>('Apple');
  const [generatedBatch, setGeneratedBatch] = useState<
    Array<{ imei: string; brand: string; model: string }>
  >([]);

  // Calculate Luhn check digit
  const calculateLuhn = (first14Digits: string): number => {
    let sum = 0;
    for (let i = 0; i < 14; i++) {
      let digit = parseInt(first14Digits[i] || '0', 10);
      if (i % 2 === 1) {
        digit *= 2;
        if (digit > 9) digit = Math.floor(digit / 10) + (digit % 10);
      }
      sum += digit;
    }
    return (10 - (sum % 10)) % 10;
  };

  // Masking implementation
  const maskImei = (imei: string, style: MaskingStyle, char: string = '•'): string => {
    const clean = imei.replace(/\D/g, '');
    if (clean.length < 14) return clean;

    const tac = clean.substring(0, 8);
    const cd = clean.length >= 15 ? clean.substring(14, 15) : '';

    switch (style) {
      case 'support':
        return `${tac} ${char.repeat(6)} ${cd}`.trim();
      case 'receipt':
        return `${char.repeat(11)} ${clean.slice(-4)}`;
      case 'strict':
        return `[REDACTED-IMEI]`;
      case 'token': {
        const pseudoHash = Math.abs(
          clean.split('').reduce((acc, c) => ((acc << 5) - acc + c.charCodeAt(0)) | 0, 0)
        )
          .toString(16)
          .toUpperCase()
          .padStart(8, '0');
        return `PRV-IMEI-${pseudoHash.slice(0, 4)}-${pseudoHash.slice(4, 8)}`;
      }
      case 'custom':
        return `${clean.substring(0, 6)}${char.repeat(8)}${clean.slice(-1)}`;
      default:
        return `${tac} ${char.repeat(6)} ${cd}`;
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Clean IMEI input analysis
  const cleanImei = inputImei.replace(/\D/g, '');
  const tacPart = cleanImei.substring(0, 8);
  const snrPart = cleanImei.substring(8, 14);
  const cdPart = cleanImei.substring(14, 15);
  const expectedCd = cleanImei.length >= 14 ? calculateLuhn(cleanImei.substring(0, 14)) : null;
  const isLuhnValid = expectedCd !== null && cdPart === expectedCd.toString();

  // NV Item 550 BCD Hex representation & Masked NVM Hex
  const nv550Data = useMemo(() => {
    const encoded = encodeImeiToNv550Hex(cleanImei || '358942110294854');
    // Mask the SNR bytes (bytes 5, 6, 7, 8) while keeping length + TAC bytes (0..4)
    const maskedHexBytes = encoded.hexBytes.map((b, idx) => (idx >= 5 ? 'XX' : b));
    return {
      rawHex: encoded.formattedHex,
      maskedHex: maskedHexBytes.join(' '),
    };
  }, [cleanImei]);

  // Redacted bulk text calculation (scrubs both 15-digit decimal IMEIs and 9-byte NV Item 550 BCD hex frames)
  const scrubbedResult = useMemo(() => {
    const imeiRegex = /\b(\d{14,16})\b/g;
    const nv550HexRegex = /\b08\s+[0-9A-Fa-f][Aa]\s+(?:[0-9A-Fa-f]{2}\s+){2}([0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2})\b/g;
    let count = 0;

    let replaced = scrubberInput.replace(imeiRegex, (match) => {
      count++;
      return maskImei(match, scrubberMaskStyle, maskChar);
    });

    replaced = replaced.replace(nv550HexRegex, (fullMatch, snrGroup) => {
      count++;
      return fullMatch.replace(snrGroup, 'XX XX XX XX');
    });

    return { text: replaced, count };
  }, [scrubberInput, scrubberMaskStyle, maskChar]);

  // Generate synthetic test batch
  const generateTestImeis = (brand: string, count: number = 4) => {
    const tacMap: Record<string, { tac: string; model: string }> = {
      Apple: { tac: '35894211', model: 'iPhone 15 Pro Max (Sandbox)' },
      Samsung: { tac: '35284911', model: 'Galaxy S24 Ultra (Sandbox)' },
      Google: { tac: '35489209', model: 'Pixel 8 Pro (Sandbox)' },
      Motorola: { tac: '35728409', model: 'Edge 40 Pro (Sandbox)' },
      OnePlus: { tac: '35928410', model: 'OnePlus 12 (Sandbox)' },
    };

    const target = tacMap[brand] || tacMap['Apple'];
    const results = [];

    for (let i = 0; i < count; i++) {
      const randomSnr = Math.floor(100000 + Math.random() * 900000).toString();
      const first14 = `${target.tac}${randomSnr}`;
      const cd = calculateLuhn(first14);
      results.push({
        imei: `${first14}${cd}`,
        brand,
        model: target.model,
      });
    }

    setGeneratedBatch(results);
  };

  const handleDownloadScrubbed = () => {
    const blob = new Blob([scrubbedResult.text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'scrubbed-telephony-nvm-log.txt';
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      {/* Top Header Banner */}
      <div className="rounded-2xl bg-slate-900 p-6 sm:p-8 border border-slate-800">
        <div className="max-w-3xl space-y-2">
          <div className="flex items-center gap-2 text-xs text-cyan-400 font-medium">
            <span>GSMA EIR Identity Protection</span>
            <span aria-hidden="true">·</span>
            <span>NV Item 550 BCD Hex Redaction</span>
            <span aria-hidden="true">·</span>
            <span>3GPP TS 23.003 &amp; Luhn-10</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            IMEI &amp; Baseband NVM Redaction Workbench
          </h1>

          <p className="text-slate-300 text-sm leading-relaxed">
            Protect your hardware identity before sharing carrier support tickets, UART/DIAG serial dumps, or QFIL/Odin logs on XDA and public forums. Redact unique serial numbers (SNR) in both 15-digit decimal and 9-byte Non-Volatile Memory (NV Item 550) BCD hex formats.
          </p>
        </div>
      </div>

      {/* Main Grid: Single Masker & Bulk Scrubber */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Interactive Single IMEI & NVM Hex Masker */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div>
                <h2 className="text-base font-bold text-white">Single IMEI &amp; NVM Item 550 Masker</h2>
                <p className="text-xs text-slate-400">
                  Generate privacy-safe strings for carrier forums &amp; baseband research papers
                </p>
              </div>

              {/* Verified Device Preset Selector */}
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-slate-400 hidden sm:inline">Preset:</span>
                <select
                  onChange={(e) => setInputImei(e.target.value)}
                  className="bg-slate-950 border border-slate-700 text-xs text-slate-300 rounded-lg px-2.5 py-1.5 focus:border-cyan-500 focus:outline-none cursor-pointer"
                >
                  {VERIFIED_DEVICE_PROFILES.map((s) => (
                    <option key={s.imei} value={s.imei}>
                      {s.label.split('(')[0]}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Input Box */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                <span>Enter 15-Digit Device IMEI</span>
                <span
                  className={`text-xs font-mono tabular-nums ${
                    cleanImei.length === 15 ? 'text-emerald-400' : 'text-amber-400'
                  }`}
                >
                  {cleanImei.length}/15 Digits
                </span>
              </label>

              <div className="relative">
                <input
                  type="text"
                  value={inputImei}
                  onChange={(e) => setInputImei(e.target.value)}
                  placeholder="e.g. 358942110294854"
                  maxLength={18}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl px-4 py-3 text-sm text-white font-mono tabular-nums placeholder-slate-600 transition"
                />
                <button
                  type="button"
                  onClick={() => setInputImei('')}
                  className="absolute right-3 top-3 text-xs text-slate-500 hover:text-slate-300 transition cursor-pointer"
                >
                  Clear
                </button>
              </div>
            </div>

            {/* IMEI Architecture Inspection (TAC + SNR + CD) */}
            {cleanImei.length >= 8 && (
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3">
                <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5 text-cyan-400" />
                  <span>3GPP TS 23.003 Hardware Breakdown</span>
                </span>

                <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono tabular-nums">
                  <div className="bg-slate-900 border border-slate-800 rounded-lg p-2.5">
                    <span className="text-[10px] text-cyan-400 font-bold block">TAC (Digits 1–8)</span>
                    <span className="text-sm font-bold text-cyan-200">{tacPart || '--------'}</span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">OEM &amp; Model</span>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 rounded-lg p-2.5">
                    <span className="text-[10px] text-amber-400 font-bold block">SNR (Digits 9–14)</span>
                    <span className="text-sm font-bold text-amber-200">{snrPart || '------'}</span>
                    <span className="text-[10px] text-amber-400 block mt-0.5">Sensitive Serial</span>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 rounded-lg p-2.5">
                    <span className="text-[10px] text-indigo-400 font-bold block">CD (Digit 15)</span>
                    <span className={`text-sm font-bold ${isLuhnValid ? 'text-emerald-400' : 'text-slate-300'}`}>
                      {cdPart || '-'}
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">
                      {isLuhnValid ? 'Valid Luhn-10' : 'Checksum'}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Masking Style Presets */}
            <div className="space-y-3">
              <label className="text-xs font-semibold text-slate-300 block">
                Select Redaction Mode
              </label>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'support', name: 'Carrier Support', desc: 'Keeps TAC, masks SNR', icon: Shield },
                  { id: 'receipt', name: 'Invoice / Store', desc: 'Last 4 digits visible', icon: FileText },
                  { id: 'token', name: 'Privacy Token', desc: 'Hash pseudonym', icon: Hash },
                  { id: 'strict', name: 'Strict Redaction', desc: 'Total scrub', icon: Lock },
                ].map((preset) => {
                  const Icon = preset.icon;
                  const isSelected = selectedStyle === preset.id;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => setSelectedStyle(preset.id as MaskingStyle)}
                      className={`p-3 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                        isSelected
                          ? 'bg-cyan-500/15 border-cyan-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <Icon className={`w-4 h-4 ${isSelected ? 'text-cyan-400' : 'text-slate-500'}`} />
                        {isSelected && <Check className="w-3 h-3 text-cyan-400" />}
                      </div>
                      <span className="text-xs font-bold block">{preset.name}</span>
                      <span className="text-[10px] text-slate-500 block">{preset.desc}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Masking Character Toggle */}
            <div className="flex items-center justify-between bg-slate-950 border border-slate-800 rounded-xl px-4 py-3">
              <span className="text-xs text-slate-300 font-medium">Redaction Character:</span>
              <div className="flex gap-1.5">
                {['•', '*', 'X', '#'].map((char) => (
                  <button
                    key={char}
                    type="button"
                    onClick={() => setMaskChar(char)}
                    className={`w-7 h-7 rounded-lg text-xs font-mono font-bold transition cursor-pointer flex items-center justify-center ${
                      maskChar === char
                        ? 'bg-cyan-500 text-slate-950 font-black'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {char}
                  </button>
                ))}
              </div>
            </div>

            {/* Decimal Masked Result */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Masked Decimal Output</span>
                </span>
                <button
                  type="button"
                  onClick={() => handleCopy(maskImei(inputImei, selectedStyle, maskChar), 'single-mask')}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-semibold border border-cyan-500/40 transition cursor-pointer"
                >
                  {copiedId === 'single-mask' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Copy Masked IMEI</span>
                    </>
                  )}
                </button>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 font-mono tabular-nums text-base text-white font-bold tracking-wider select-all break-all">
                {maskImei(inputImei, selectedStyle, maskChar)}
              </div>
            </div>

            {/* Baseband NV Item 550 (0x0226) BCD Hex Masker */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                  <Binary className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Modem NVM Register (NV_UE_IMEI_I / Item 550) BCD Hex Redaction</span>
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleCopy(nv550Data.maskedHex, 'nv550-mask')}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 flex items-center gap-1 cursor-pointer"
                  >
                    {copiedId === 'nv550-mask' ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span>Copied NVM Hex</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy Redacted Hex</span>
                      </>
                    )}
                  </button>
                  {onOpenBasebandNvm && (
                    <button
                      type="button"
                      onClick={() => onOpenBasebandNvm(cleanImei || '358942110294854')}
                      className="px-2.5 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <span>Inspect in NVM Lab</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono tabular-nums">
                <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Unmasked 9-Byte BCD in NVM:</span>
                  <span className="text-amber-300 font-bold">{nv550Data.rawHex}</span>
                </div>
                <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Scrubbed NVM Hex (Safe for Papers/XDA):</span>
                  <span className="text-emerald-400 font-bold">{nv550Data.maskedHex}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Bulk Log & UART Dump Scrubber + Test Generator */}
        <div className="lg:col-span-5 space-y-6">
          {/* Bulk Text & UART Log Scrubber */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-white">UART Serial, QFIL &amp; Email Log Scrubber</h3>
                <p className="text-[11px] text-slate-400">
                  Auto-detects &amp; masks decimal IMEIs and NV Item 550 hex frames
                </p>
              </div>

              <span className="text-xs font-mono tabular-nums text-emerald-400 font-semibold">
                {scrubbedResult.count} Identifier{scrubbedResult.count === 1 ? '' : 's'} Scrubbed
              </span>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs text-slate-300 font-medium">Input Diagnostic Log</label>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      setScrubberInput(
                        `[UART 115200] DIAG TX: NV_READ_F (0x26) Item 550 (0x0226)\n[NVM DUMP] 0x00022600: 08 3A 58 94 21 10 29 48 54\n[BASEBAND] Primary IMEI: 358942110294854 | eSIM IMEI2: 358942110294862`
                      )
                    }
                    className="text-[11px] text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
                  >
                    Load UART / NVM Dump
                  </button>
                  <button
                    type="button"
                    onClick={() => setScrubberInput('')}
                    className="text-[11px] text-slate-500 hover:text-slate-300 cursor-pointer"
                  >
                    Clear
                  </button>
                </div>
              </div>

              <textarea
                value={scrubberInput}
                onChange={(e) => setScrubberInput(e.target.value)}
                rows={5}
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 rounded-xl p-3 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none transition resize-none"
                placeholder="Paste unlock confirmation email, UART serial capture, or QFIL log..."
              />
            </div>

            {/* Redacted Preview */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs text-slate-300 font-medium">Scrubbed Output</label>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleCopy(scrubbedResult.text, 'bulk-scrub')}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center gap-1 transition cursor-pointer"
                  >
                    {copiedId === 'bulk-scrub' ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3 text-slate-400" />
                        <span>Copy All</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={handleDownloadScrubbed}
                    className="px-2.5 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-medium flex items-center gap-1 transition cursor-pointer"
                  >
                    <Download className="w-3 h-3" />
                    <span>Save .txt</span>
                  </button>
                </div>
              </div>

              <div className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-mono text-emerald-300 max-h-36 overflow-y-auto whitespace-pre-wrap select-all">
                {scrubbedResult.text}
              </div>
            </div>
          </div>

          {/* Synthetic Test IMEI Generator */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-white">3GPP Sandbox Test IMEI Generator</h3>
                <p className="text-[11px] text-slate-400">
                  Generate Luhn-verified synthetic IMEIs for academic papers &amp; QA
                </p>
              </div>

              <button
                type="button"
                onClick={() => generateTestImeis(testBrand, 3)}
                className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Generate Batch</span>
              </button>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-400 font-medium">Target TAC:</span>
              <div className="flex flex-wrap gap-1.5">
                {['Apple', 'Samsung', 'Google', 'Motorola', 'OnePlus'].map((b) => (
                  <button
                    key={b}
                    type="button"
                    onClick={() => {
                      setTestBrand(b);
                      generateTestImeis(b, 3);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition cursor-pointer ${
                      testBrand === b
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                        : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
                    }`}
                  >
                    {b}
                  </button>
                ))}
              </div>
            </div>

            {/* Generated List */}
            <div className="space-y-2">
              {generatedBatch.length === 0 ? (
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-center">
                  <p className="text-xs text-slate-400 mb-2">No synthetic test batch generated yet.</p>
                  <button
                    type="button"
                    onClick={() => generateTestImeis('Apple', 3)}
                    className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
                  >
                    Generate verified Apple iPhone 15 sandbox batch
                  </button>
                </div>
              ) : (
                <div className="space-y-1.5">
                  {generatedBatch.map((item, idx) => (
                    <div
                      key={idx}
                      className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 flex items-center justify-between text-xs font-mono tabular-nums"
                    >
                      <div>
                        <span className="text-white font-bold">{item.imei}</span>
                        <span className="text-[10px] text-slate-500 ml-2">({item.model})</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleCopy(item.imei, `test-${idx}`)}
                        className="text-slate-400 hover:text-cyan-300 transition cursor-pointer p-1"
                        title="Copy Test IMEI"
                      >
                        {copiedId === `test-${idx}` ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
