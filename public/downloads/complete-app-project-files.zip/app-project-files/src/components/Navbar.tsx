import React from 'react';
import {
  Smartphone,
  Unlock,
  Search,
  ShieldCheck,
  Sparkles,
  Building2,
  Key,
  DollarSign,
  Database,
  CheckCircle2,
  Zap,
  Eye,
  EyeOff,
  Cpu,
  Package,
  Box,
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenDialerModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, onOpenDialerModal }) => {
  const tabs = [
    { id: 'boot-bios-sandbox', label: 'Modem Rewriter & Boot/BIOS Container', icon: Box },
    { id: 'baseband-lab', label: 'Baseband & Firmware Lab', icon: Cpu },
    { id: 'shizuku', label: 'Shizuku IPC Bridge', icon: Zap },
    { id: 'imei-lookup', label: 'IMEI Phone Lookup', icon: Search },
    { id: 'imei-masking', label: 'IMEI & NVM Masker', icon: EyeOff },
    { id: 'secret-menus', label: 'Secret Menus', icon: Eye },
    { id: 'codes-db', label: 'Unlock Codes DB', icon: Database },
    { id: 'imei', label: 'Carrier Diagnostic', icon: CheckCircle2 },
    { id: 'wizard', label: 'Universal Wizard', icon: Unlock },
    { id: 'check-status', label: 'Lock Status Guide', icon: ShieldCheck },
    { id: 'nck', label: 'NCK & MCK Decoder', icon: Key },
    { id: 'carriers', label: 'Carrier Directory', icon: Building2 },
    { id: 'advisor', label: 'AI Policy Advisor', icon: Sparkles },
    { id: 'savings', label: 'Switch Calculator', icon: DollarSign },
    { id: 'apk-compiler', label: 'APK Build & Package', icon: Package },
  ];

  return (
    <header className="sticky top-0 z-50 bg-[#060911]/90 backdrop-blur-xl border-b border-slate-800/80 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Bar Contract: Zone 1 Brand Logo — Zone 2 Core Quick Nav — Zone 3 Primary Action */}
        <div className="flex items-center justify-between gap-4 h-16">
          {/* Zone 1: New Futuristic Hexagonal Baseband Core Logo + Wordmark */}
          <button
            type="button"
            onClick={() => setActiveTab('baseband-lab')}
            className="flex items-center gap-3 group cursor-pointer shrink-0"
          >
            <div className="relative w-10 h-10 rounded-xl bg-slate-950 border border-cyan-500/40 group-hover:border-emerald-400/70 flex items-center justify-center shadow-lg shadow-cyan-500/10 transition-all overflow-hidden">
              <svg
                viewBox="0 0 64 64"
                className="w-8 h-8"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <defs>
                  <linearGradient id="navHexGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#22D3EE" />
                    <stop offset="50%" stopColor="#10B981" />
                    <stop offset="100%" stopColor="#6366F1" />
                  </linearGradient>
                </defs>
                {/* Outer Hexagon */}
                <polygon
                  points="32,5 56,18.5 56,45.5 32,59 8,45.5 8,18.5"
                  fill="#091024"
                  stroke="url(#navHexGrad)"
                  strokeWidth="3"
                  strokeLinejoin="round"
                />
                {/* Circuit Bus Pins */}
                <line x1="32" y1="5" x2="32" y2="13" stroke="#22D3EE" strokeWidth="2" strokeLinecap="round" />
                <line x1="32" y1="51" x2="32" y2="59" stroke="#10B981" strokeWidth="2" strokeLinecap="round" />
                <line x1="8" y1="18.5" x2="15" y2="22.5" stroke="#22D3EE" strokeWidth="2" strokeLinecap="round" />
                <line x1="49" y1="41.5" x2="56" y2="45.5" stroke="#6366F1" strokeWidth="2" strokeLinecap="round" />
                {/* Unlocked Shackle Arc */}
                <path
                  d="M 26 28 V 21 C 26 17.5 28.5 15 32 15 C 35 15 37.5 17 38 20"
                  stroke="#10B981"
                  strokeWidth="3.2"
                  strokeLinecap="round"
                />
                {/* Central Baseband Chip Core */}
                <rect x="21" y="27" width="22" height="18" rx="4" fill="url(#navHexGrad)" />
                <circle cx="32" cy="34.5" r="2.5" fill="#050811" />
                <path d="M 30.5 36 L 29.5 41.5 H 34.5 L 33.5 36 Z" fill="#050811" />
              </svg>
            </div>
            <div className="text-left">
              <div className="flex items-center gap-1.5">
                <span className="text-lg font-black tracking-tight bg-gradient-to-r from-white via-cyan-200 to-emerald-300 bg-clip-text text-transparent">
                  OMNIUNLOCK
                </span>
                <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                  PRO
                </span>
              </div>
              <span className="block text-[10px] font-mono text-slate-400 tracking-wider uppercase">
                Baseband · Shizuku · 3GPP Lab
              </span>
            </div>
          </button>

          {/* Zone 2: Concise single-line core workspace links */}
          <nav className="hidden lg:flex items-center gap-6 text-xs font-medium text-slate-400">
            {[
              { id: 'baseband-lab', label: 'Baseband Lab' },
              { id: 'shizuku', label: 'Shizuku Bridge' },
              { id: 'imei-lookup', label: 'IMEI Lookup' },
              { id: 'imei-masking', label: 'NVM Masker' },
              { id: 'secret-menus', label: 'Secret Menus' },
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`transition-colors whitespace-nowrap shrink-0 cursor-pointer py-1 ${
                  activeTab === item.id
                    ? 'text-cyan-300 underline underline-offset-8 decoration-cyan-400 decoration-2 font-semibold'
                    : 'hover:text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Zone 3: Dialer Helper (No front-page download clutter) */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={onOpenDialerModal}
              className="flex items-center gap-2 text-xs font-semibold px-3.5 py-2 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-500/40 transition-all cursor-pointer whitespace-nowrap shrink-0"
              title="How to find your IMEI on any phone"
            >
              <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
              <span>Dial *#06# Helper</span>
            </button>
          </div>
        </div>

        {/* Workspace Module Switcher Toolbar */}
        <div className="flex space-x-1.5 overflow-x-auto pb-2.5 pt-2 border-t border-slate-800/60 text-xs font-medium">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl whitespace-nowrap shrink-0 transition-all cursor-pointer ${
                  isActive
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900/80 border border-transparent hover:border-slate-800'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-slate-950' : 'text-cyan-400/80'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
