#!/usr/bin/env bash
echo "===================================================================="
echo "OmniUnlock-Suite v2.5.0 - ADB APK Installer"
echo "===================================================================="
adb install -r -d -g "Universal-APK-Studio-App-v2.5.0-signed.apk"
echo "✓ Installation complete!"
