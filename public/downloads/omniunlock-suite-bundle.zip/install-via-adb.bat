@echo off
echo ====================================================================
echo OmniUnlock-Suite v2.5.0 - ADB APK Installer
echo ====================================================================
adb devices
echo Installing Universal-APK-Studio-App-v2.5.0-signed.apk...
adb install -r -d -g Universal-APK-Studio-App-v2.5.0-signed.apk
echo Done!
pause
